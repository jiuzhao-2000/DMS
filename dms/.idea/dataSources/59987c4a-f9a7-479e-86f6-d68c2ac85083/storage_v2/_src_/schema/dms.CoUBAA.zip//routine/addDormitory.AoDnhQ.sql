create
    definer = root@localhost procedure addDormitory(IN num int)
begin
	#创建宿舍的属性
	DECLARE bid INT DEFAULT 1;
    DECLARE did INT DEFAULT 0;
	DECLARE occupancy int default 0;
    DECLARE bedNum int;
    DECLARE waterAndElectricity double;
    DECLARE isPay boolean;
    DECLARE health int;
    #创建学生
    DECLARE sid int default 1000000000;
    DECLARE pwd varchar(10) default '123456';
    DECLARE sname nvarchar(10) default '久曌';
    DECLARE sex nchar(1) default '男';
    DECLARE state nvarchar(10) default '住宿';
	#创建访客
	declare vid int8 default 350722200000000000;
	declare vname char(10) default '久曌';
    
    declare peopleNum int default 0;
    declare i int default 1;
    declare cnt int default 0;
    
    insert into maintainer(pwd,`name`,phone) values('123456','久曌','18295000000'),('123456','root','13295000000'),('123456','jiuzhao','19218600000'),('123456','jack','17216812345');
	
    while bid <= num DO
		set did = 101;
        IF bid>5 THEN
			set sex='男';
		ELSE
			set sex='女';
		END IF;
        #begin 创建一栋楼成员
		while did < 513  do
            # 获取宿舍人数
            set peopleNum = floor(rand()*4);
            #begin 创建宿舍入住序列
            if peopleNum = 0 then
				set occupancy=0;
            elseif  peopleNum = 1 then
				set occupancy=1;
            elseif  peopleNum = 2 then
				set occupancy=3;
			elseif  peopleNum = 3 then
				set occupancy=7;
			else
                set occupancy=15;
            end if;
			while peopleNum>cnt do
				set occupancy=occupancy+i<<cnt;
				set cnt=cnt+1;
            end while;
            #end 创建宿舍状态序列
			insert into Dormitory (did ,bid ,occupancy,bedNum,waterAndElectricity,isPay,health) values (did ,bid,occupancy,4,rand()*100,true,floor(rand()*100));
            #begin 创建财产
            insert into wealth(`value`,`name`,bid,did) values
            (99.9,'电灯',bid,did),
            (88.8,'风扇',bid,did),
            (77.7,'门把手',bid,did),
            (2000.2,'空调',bid,did),
            (222,'衣柜',bid,did),
            (500,'床',bid,did),
            (600,'插座',bid,did),
            (666,'水龙头',bid,did),
            (777,'下水道',bid,did),
            (888,'厕所',bid,did);
            
            #end 创建财产
			#begin 创建宿舍成员
            while peopleNum>0 do
				set sname=concat(SUBSTRING('赵钱孙李周吴郑王林杨柳刘孙陈江阮侯邹高彭徐',FLOOR(1+21*RAND()),1),SUBSTRING('一二三四五六七八九十甲乙丙丁静景京晶名明铭敏闵民军君俊骏天田甜兲恬益依成城诚立莉力黎励',ROUND(1+43*RAND()),1),SUBSTRING('一二三四五六七八九十甲乙丙丁静景京晶名明铭敏闵民军君俊骏天田甜兲恬益依成城诚立莉力黎励',ROUND(1+43*RAND()),1));
				insert into student(sid,pwd,`name`,sex,bid,did,bedid,state,phone) values(cast(sid as char(10)),pwd,sname,sex,bid,did,peopleNum,occupancy,'18350970000'); 
                set sid=sid+1;
                set peopleNum = peopleNum-1;
            end while;
            #end 创建宿舍成员
            set did = did+1;
		end while;
        #end 创建一栋楼成员
        SET bid = bid+ 1;
	END WHILE;
    #begin 创建修理记录
    set cnt=1;
    while cnt<5000 do
		insert into Maintained(mid,wid,maintainTime) values(floor(1+rand()*4),cnt,now());
		set cnt=cnt+1;
    end while;
    #end 创建修理记录
    #begin 创建订单
    insert into `repairList`(repairTime) values(now()),(now()),(now());
    set cnt=1;
    while cnt<20 do
		insert into `repair`(rid,wid,question) values(floor(1+rand()*3),cnt,'坏了');
		set cnt=cnt+1;
    end while;
    #end 创建订单
    #begin 创建参观者
    set cnt=1000000000;
    while cnt<sid  do
        set vname=concat(SUBSTRING('赵钱孙李周吴郑王林杨柳刘孙陈江阮侯邹高彭徐',FLOOR(1+21*RAND()),1),SUBSTRING('一二三四五六七八九十甲乙丙丁静景京晶名明铭敏闵民军君俊骏天田甜兲恬益依成城诚立莉力黎励',ROUND(1+43*RAND()),1),SUBSTRING('一二三四五六七八九十甲乙丙丁静景京晶名明铭敏闵民军君俊骏天田甜兲恬益依成城诚立莉力黎励',ROUND(1+43*RAND()),1));
		insert into Visitor(vid,`name`,phone) values(cast(vid as char(18)),vname,concat('1900000000',substring('1234567890',floor(1+10*rand()),1)));
        insert into visit(sid,vid,visitTime,visitedTime,relationship) values(cnt,cast(vid as char(18)),now(),now(),'亲属') ;
        set vid = vid+1;
		set cnt = cnt+1;
    end while;
    #end 创建参观者
end;

